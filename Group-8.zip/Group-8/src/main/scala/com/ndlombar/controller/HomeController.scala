//package com.ndlombar.controller;
//
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class HomeController {
//
//	@RequestMapping("/")
//	public String home() {
//		return "testing new rentmate spring boot app.";
//	}
//}
