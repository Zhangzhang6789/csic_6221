package com.ndlombar.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ndlombar.dao.AnnouncementRepository;
import com.ndlombar.dao.ApartmentRepository;
import com.ndlombar.dao.DueRepository;
import com.ndlombar.dao.ReviewRepository;
import com.ndlombar.dao.StatementRepository;
import com.ndlombar.dao.TicketRepository;
import com.ndlombar.dao.TourRepository;
import com.ndlombar.dao.UserRepository;
import com.ndlombar.entity.Apartment;
import com.ndlombar.entity.Coupon;
import com.ndlombar.entity.Due;
import com.ndlombar.entity.ManagerApartments;
import com.ndlombar.entity.ManagerPortal;
import com.ndlombar.entity.Statement;
import com.ndlombar.entity.Ticket;
import com.ndlombar.entity.Tour;
import com.ndlombar.entity.User;
import com.ndlombar.model.ManagerApartmentResponse;
import com.ndlombar.model.ManagerUserResponse;

@RestController
public class ManagerController {
	
	@Autowired
	UserRepository userRepo;
	@Autowired
	StatementRepository statementRepo;
	@Autowired
	TicketRepository ticketRepo;
	@Autowired
	ReviewRepository reviewRepo;
	@Autowired
	DueRepository dueRepo;
	@Autowired 
	AnnouncementRepository ancRepo;
	@Autowired
	ApartmentRepository apartmentRepo;
	@Autowired
	TourRepository tourRepo;
	

	@CrossOrigin
	@GetMapping(path="/getAllUsersForManager")
	public ResponseEntity<?> getAllUsersForManager (@RequestParam Integer managerId) {
		List<Apartment> apartmentsOwened = null;
		List<ManagerPortal> users = new ArrayList<>();
		
		
		apartmentsOwened = apartmentRepo.getApartmentsByManagerId(managerId);
		User user = new User();
		List<Statement> statements = null;
		List<Ticket> tickets = null;
		List<Due> dues = null;
		List<Coupon> coupons = null;
		
		for(Apartment a : apartmentsOwened) {
			if(a.getTenantId() != null) {
				ManagerPortal mp = new ManagerPortal();
				user = userRepo.findByUid(a.getTenantId());
				
				statements = statementRepo.findAllByUid(user.getUid());
				tickets = ticketRepo.findAllByUid(user.getUid());
				dues = dueRepo.findAllByUid(user.getUid());
				
				coupons = new ArrayList<>();
				coupons.add(new Coupon("50OFF", "Rent", -0.5));
				coupons.add(new Coupon("FREELATE", "Late fee", -1.0));
				
				mp.setUser(user);
				mp.setDues(dues);
				mp.setStatements(statements);
				mp.setTickets(tickets);
				mp.setCoupons(coupons);
				
				users.add(mp);
			}
		}
		
		
		return ResponseEntity.ok(new ManagerUserResponse(true, users));
	}
	
	@CrossOrigin
	@GetMapping(path="/getAllApartmentsForManager")
	public ResponseEntity<?> getAllApartmentsForManager (@RequestParam Integer managerId) {
		List<Apartment> apartmentsOwened = null;
		List<ManagerApartments> result = new ArrayList<>();
		List<Tour> tours = new ArrayList<>();
		apartmentsOwened = apartmentRepo.getApartmentsByManagerId(managerId);
		for(Apartment a : apartmentsOwened) {
			ManagerApartments ma = new ManagerApartments();
			tours = tourRepo.findAllByAid(a.getApartmentId());
			ma.setApartment(a);
			ma.setTours(tours);
			
			result.add(ma);
		}

		return ResponseEntity.ok(new ManagerApartmentResponse(true, result));
	}
}
