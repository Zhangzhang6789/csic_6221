package com.ndlombar.controller;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ndlombar.dao.ForumgroupRepository;
import com.ndlombar.dao.ForumtopicRepository;
import com.ndlombar.dao.TopicmessageRepository;
import com.ndlombar.dao.UserRepository;
import com.ndlombar.entity.Forumgroup;
import com.ndlombar.entity.Forumtopic;
import com.ndlombar.entity.Topicmessage;
import com.ndlombar.entity.User;
import com.ndlombar.model.ForumResponse;
import com.ndlombar.model.NewGroupRequest;
import com.ndlombar.model.NewGroupResponse;
import com.ndlombar.model.NewMessageRequest;
import com.ndlombar.model.NewMessageResponse;
import com.ndlombar.model.NewTopicRequest;
import com.ndlombar.model.NewTopicResponse;

@RestController
public class ForumController {
	
	@Autowired
	ForumgroupRepository forumgroupRepo;
	@Autowired
	ForumtopicRepository forumtopicRepo;
	@Autowired
	TopicmessageRepository topicmessageRepo;
	@Autowired
	UserRepository userRepo;
	
	@CrossOrigin
	@GetMapping(path="/getForumData")
	public ResponseEntity<?> getForumData() {
		List<Forumgroup> groups = null;
		List<Forumtopic> topics = null;
		List<Topicmessage> messages = null;
		
		groups = (List<Forumgroup>) forumgroupRepo.findAll();
		topics = (List<Forumtopic>) forumtopicRepo.findAll();
		messages = (List<Topicmessage>) topicmessageRepo.findAll();
		
		return ResponseEntity.ok(new ForumResponse(true, groups, topics, messages));
	}
	
	@CrossOrigin
	@PostMapping(path="/newGroup")
	public ResponseEntity<?> newGroup(@RequestBody NewGroupRequest groupReq) {
		Forumgroup fg = new Forumgroup();
		fg.setName(groupReq.getName());
		fg.setDescription(groupReq.getDescription());
		
		Forumgroup newFg = forumgroupRepo.save(fg);
		if(newFg != null) {
			return ResponseEntity.ok(new NewGroupResponse(true, newFg));
		} else {
			return ResponseEntity.ok(new NewGroupResponse(false, null));
		}
	}
	
	@CrossOrigin
	@PostMapping(path="/newTopic")
	public ResponseEntity<?> newTopic(@RequestBody NewTopicRequest topicReq) {
		Forumgroup group = forumgroupRepo.findForumgroupByGid(topicReq.getGroupId());
		
		if(group != null) {
			Forumtopic topic = new Forumtopic();
			topic.setGid(topicReq.getGroupId());
			topic.setTitle(topicReq.getTitle());
			topic.setDescription(topicReq.getDescription());
			topic.setMessage(topicReq.getMessage());
			
			Forumtopic newTopic = forumtopicRepo.save(topic);
			
			return ResponseEntity.ok(new NewTopicResponse(true, newTopic));
		} else {
			return ResponseEntity.ok(new NewTopicResponse(false, null));
		}
	}
	
	@CrossOrigin
	@PostMapping(path="/newTopicMessage")
	public ResponseEntity<?> newTopicMessage(@RequestBody NewMessageRequest messageReq) {
		Forumtopic topic = forumtopicRepo.findForumtopicByTid(messageReq.getTopicId());
		User u = userRepo.findByUid(messageReq.getUserId());
		if(topic != null && u != null) {
			Topicmessage message = new Topicmessage();
			message.setTid(messageReq.getTopicId());
			message.setUid(messageReq.getUserId());
			message.setUserName(u.getFirstname() + " "+ u.getLastname());
			message.setTime(new Timestamp(System.currentTimeMillis()));
			message.setMessage(messageReq.getMessage());
			
			Topicmessage newMsg = topicmessageRepo.save(message);
			
			return ResponseEntity.ok(new NewMessageResponse(true, newMsg));
		} else {
			return ResponseEntity.ok(new NewMessageResponse(false, null));
		}
	}
}
