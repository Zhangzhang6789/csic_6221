package com.ndlombar.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ndlombar.dao.AnnouncementRepository;
import com.ndlombar.dao.ApartmentRepository;
import com.ndlombar.dao.DueRepository;
import com.ndlombar.dao.ForumgroupRepository;
import com.ndlombar.dao.ForumtopicRepository;
import com.ndlombar.dao.ReviewRepository;
import com.ndlombar.dao.StatementRepository;
import com.ndlombar.dao.TicketRepository;
import com.ndlombar.dao.TopicmessageRepository;
import com.ndlombar.dao.UserRepository;
import com.ndlombar.entity.Announcement;
import com.ndlombar.entity.Apartment;
import com.ndlombar.entity.Coupon;
import com.ndlombar.entity.Due;
import com.ndlombar.entity.Forumgroup;
import com.ndlombar.entity.Forumtopic;
import com.ndlombar.entity.ResidentPortal;
import com.ndlombar.entity.Review;
import com.ndlombar.entity.Statement;
import com.ndlombar.entity.Ticket;
import com.ndlombar.entity.Topicmessage;
import com.ndlombar.entity.User;
import com.ndlombar.model.ApiResponse;
import com.ndlombar.model.ForumResponse;
import com.ndlombar.model.MessageResponse;
import com.ndlombar.model.NewTicketRequest;
import com.ndlombar.model.PaymentRequest;
import com.ndlombar.model.RatingResponse;
import com.ndlombar.model.RatingsRequest;
import com.ndlombar.model.ResidentPortalResponse;
import com.ndlombar.model.TicketResponse;

@RestController
public class UserController {
	@Autowired
	UserRepository userRepo;
	@Autowired
	StatementRepository statementRepo;
	@Autowired
	TicketRepository ticketRepo;
	@Autowired
	ReviewRepository reviewRepo;
	@Autowired
	DueRepository dueRepo;
	@Autowired 
	AnnouncementRepository ancRepo;
	@Autowired
	ApartmentRepository apartmentRepo;
	
	
	
	
	private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
	
	@CrossOrigin
	@GetMapping(path="/residentPortal")
	public ResponseEntity<?> ResidentPortal (@RequestParam Integer userId) {
		User user = null;
		List<Statement> statements = null;
		List<Ticket> tickets = null;
		List<Due> dues = null;
		List<Coupon> coupons = null;
		ResidentPortal residentPortal = null;
		 
		user = userRepo.findByUid(userId);
		if(user != null) {
			statements = statementRepo.findAllByUid(userId);
			tickets = ticketRepo.findAllByUid(userId);
			dues = dueRepo.findAllByUid(userId);
			
			coupons = new ArrayList<>();
			coupons.add(new Coupon("50OFF", "Rent", -0.5));
			coupons.add(new Coupon("FREELATE", "Late fee", -1.0));
			
			residentPortal = new ResidentPortal();
			residentPortal.setUser(user);
			residentPortal.setStatements(statements);
			residentPortal.setTickets(tickets);
			residentPortal.setDues(dues);
			residentPortal.setCoupons(coupons);
		}
		
		return ResponseEntity.ok(new ResidentPortalResponse(true, residentPortal));
	
	}
	
	@CrossOrigin
	@PostMapping(path="/newTicket")
	public ResponseEntity<?> saveTicket(@RequestBody NewTicketRequest newTicket) {
		
		Ticket t = new Ticket();
		t.setAid(newTicket.getAid());
		t.setUid(newTicket.getUid());
		t.setTitle(newTicket.getTitle());
		t.setType(newTicket.getType());
		//t.setDate(newTicket.getDate());
		t.setDate(new Timestamp(System.currentTimeMillis()));
		t.setDescription(newTicket.getDescription());
		t.setPriority(newTicket.getPriority());
		t.setStatus(newTicket.getStatus());
		
		t = ticketRepo.save(t);
		if(t!=null) {
			return ResidentPortal(newTicket.getUid());
			//return ResponseEntity.ok(new TicketResponse(true, t));
		} else {
			return ResponseEntity.ok(new TicketResponse(false, null));
		}
	}
	
	@CrossOrigin
	@PostMapping(path="/newReview")
	public ResponseEntity<?> saveReview(@RequestBody RatingsRequest ratingReq) {
		Review r = null;
		User u = null;
		u = userRepo.findByUid(ratingReq.getUid());
		if(u != null) {
			r = new Review();
			r.setFirstName(u.getFirstname());
			r.setLastName(u.getLastname());
			r.setUid(ratingReq.getUid());
			r.setAid(ratingReq.getAid());
			r.setRating(ratingReq.getRating());
			r.setReview(ratingReq.getReview());
			
			r = reviewRepo.save(r);
			
			if(r!=null) {
				return ResponseEntity.ok(new RatingResponse(true, r));
			} else {
				return ResponseEntity.ok(new RatingResponse(false, null));
			}
		} else {
			return ResponseEntity.ok(new RatingResponse(false, null));
		}
	}
	
	@CrossOrigin
	@PostMapping(path="/makePayment")
	public ResponseEntity<?> makePayment(@RequestBody PaymentRequest paymentReq) {
		//clear due
		dueRepo.DeleteAllForUid(paymentReq.getUid());
		
		//create statement
		Statement st = new Statement();
		st.setUid(paymentReq.getUid());
		st.setDate(new Timestamp(System.currentTimeMillis()));
		st.setAmount(paymentReq.getAmount());
		st = statementRepo.save(st);
		
		//sending back updated user information.
		return ResidentPortal(paymentReq.getUid());
	}
	
	@CrossOrigin
	@GetMapping(path="/getBroadcastMessage")
	public ResponseEntity<?> getBroadcastMessages(@RequestParam Integer apartmentId) {
		List<Announcement> messageList = null;
		
		Apartment a = apartmentRepo.findApartmentByApartmentId(apartmentId);
		
		messageList = ancRepo.findAllByManagerId(a.getManagerId());
		
		if(messageList!=null) {
			return ResponseEntity.ok(new MessageResponse(true, messageList));
		} else {
			return ResponseEntity.ok(new MessageResponse(false, null));
		}
	}
	
	
	
	@CrossOrigin
	@GetMapping(path="/sendEmail")
	public ResponseEntity<?> sendEmail(@RequestParam String email, @RequestParam String content) {
		setUpMailConfiguration("rentmateservices@gmail.com", "rentmate#2019", content, email);
		
		return ResponseEntity.ok(new ApiResponse(true, "Email sent Successfully"));
	}
	
	
	private void setUpMailConfiguration(final String email, final String password,String content, final String toEmail){
        Properties props = setUpProperties();
        Authenticator auth = new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(email, password);
            }
        };
        Session session = Session.getDefaultInstance(props, auth);
        sendMails(session, email, "RentMate Announcement",content, toEmail);
    }
		    
    private void sendMails(Session session, String sender, String subject,String content, String toEmail){
        String body = content;
        sendEmail(session, sender, toEmail, subject, body);
    }
		    
    private Properties setUpProperties(){
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com"); //SMTP Host
        props.put("mail.smtp.socketFactory.port", "465"); //SSL Port
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory"); //SSL Factory Class
        props.put("mail.smtp.auth", "true"); //Enabling SMTP Authentication
        props.put("mail.smtp.port", "465"); //SMTP Port
        return props;
    }

	private static void sendEmail(Session session, String from, String toEmail, String subject, String body) {
        try {
            MimeMessage msg = new MimeMessage(session);
            //set message headers
            msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
            msg.addHeader("format", "flowed");
            msg.addHeader("Content-Transfer-Encoding", "8bit");
            msg.setFrom(new InternetAddress(from, "RentMate"));
            msg.setReplyTo(InternetAddress.parse(from, false));
            msg.setSubject(subject, "UTF-8");
            msg.setText(body, "UTF-8");
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
            Transport.send(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
