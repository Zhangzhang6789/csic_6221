package com.ndlombar.model;

import com.ndlombar.entity.Topicmessage;

public class NewMessageResponse {
	private boolean success;
	private Topicmessage message;
	
	public NewMessageResponse() {}
	
	public NewMessageResponse(boolean success, Topicmessage message) {
		this.success = success;
		this.message = message;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Topicmessage getMessage() {
		return message;
	}

	public void setMessage(Topicmessage message) {
		this.message = message;
	}
	
	
}
