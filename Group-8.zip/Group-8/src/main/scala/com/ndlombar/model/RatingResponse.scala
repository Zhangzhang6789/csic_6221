package com.ndlombar.model;

import com.ndlombar.entity.Review;

public class RatingResponse {
	private boolean success;
	private Review review;
	
	public RatingResponse(boolean success, Review review) {
		this.success = success;
		this.review = review;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Review getReview() {
		return review;
	}

	public void setReview(Review review) {
		this.review = review;
	}
	
	
	
	
}
