package com.ndlombar.model;

import java.sql.Timestamp;

import javax.persistence.Column;

public class NewTicketRequest {
	//private Timestamp date;
	private Integer uid;
	private Integer aid;
	private String title;
	private String type;
	private String priority;
	private String description;
	private String status; 
	
//	public Timestamp getDate() {
//		return date;
//	}
//	public void setDate(Timestamp date) {
//		this.date = date;
//	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public Integer getAid() {
		return aid;
	}
	public void setAid(Integer aid) {
		this.aid = aid;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
