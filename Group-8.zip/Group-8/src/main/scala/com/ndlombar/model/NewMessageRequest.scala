package com.ndlombar.model;

import java.sql.Timestamp;

public class NewMessageRequest {
	private Integer topicId;
	private Integer userId;
	//private Timestamp time;
	private String message;
	
	public NewMessageRequest() {}

	public Integer getTopicId() {
		return topicId;
	}

	public void setTopicId(Integer topicId) {
		this.topicId = topicId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

// 	public Timestamp getTime() {
// 		return time;
// 	}

// 	public void setTime(Timestamp time) {
// 		this.time = time;
// 	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
