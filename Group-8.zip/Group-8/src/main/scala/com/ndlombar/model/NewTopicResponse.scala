package com.ndlombar.model;

import com.ndlombar.entity.Forumtopic;

public class NewTopicResponse {
	private boolean success;
	private Forumtopic topic;
	
	public NewTopicResponse() {}
	
	public NewTopicResponse(boolean success, Forumtopic topic) {
		this.success = success;
		this.topic = topic;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Forumtopic getTopic() {
		return topic;
	}

	public void setTopic(Forumtopic topic) {
		this.topic = topic;
	}
	
	
}
