package com.ndlombar.model;

import com.ndlombar.entity.Ticket;

public class TicketResponse {
	private boolean success;
	private Ticket ticket;
	
	public TicketResponse(boolean success, Ticket ticket) {
		this.success = success;
		this.ticket = ticket;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	
	
}
