package com.ndlombar.model;

import java.sql.Date;

import javax.persistence.Column;

public class PostRequest {
//	private Integer postingId;
	private int apartmentId;
	private Date startAvailability;
	private Date endAvailability;
	
//	public Integer getPostingId() {
//		return postingId;
//	}
//	public void setPostingId(Integer postingId) {
//		this.postingId = postingId;
//	}
	public int getApartmentId() {
		return apartmentId;
	}
	public void setApartmentId(int apartmentId) {
		this.apartmentId = apartmentId;
	}
	public Date getStartAvailability() {
		return startAvailability;
	}
	public void setStartAvailability(Date startAvailability) {
		this.startAvailability = startAvailability;
	}
	public Date getEndAvailability() {
		return endAvailability;
	}
	public void setEndAvailability(Date endAvailability) {
		this.endAvailability = endAvailability;
	}
	
	
}
