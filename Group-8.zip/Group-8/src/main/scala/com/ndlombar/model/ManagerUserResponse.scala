package com.ndlombar.model;

import java.util.List;

import com.ndlombar.entity.ManagerPortal;

public class ManagerUserResponse {
	private boolean success;
	private List<ManagerPortal> users;
	
	public ManagerUserResponse() {}
	
	public ManagerUserResponse(boolean success, List<ManagerPortal> users) {
		this.success = success;
		this.users = users;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public List<ManagerPortal> getUsers() {
		return users;
	}

	public void setUsers(List<ManagerPortal> users) {
		this.users = users;
	}
	
	
}
