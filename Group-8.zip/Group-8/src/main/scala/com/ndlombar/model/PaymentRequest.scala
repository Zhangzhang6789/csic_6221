package com.ndlombar.model;

public class PaymentRequest {
	private Integer uid;
	private Integer aid;
	private Double amount;
	
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) { 
		this.uid = uid;
	}
	public Integer getAid() {
		return aid;
	}
	public void setAid(Integer aid) {
		this.aid = aid;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
}
