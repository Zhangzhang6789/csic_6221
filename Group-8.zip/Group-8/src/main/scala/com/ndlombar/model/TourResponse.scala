package com.ndlombar.model;

import com.ndlombar.entity.Tour;

public class TourResponse {
	private boolean success;
	private Tour tour;
	
	public TourResponse(boolean success, Tour tour) {
		this.success = success;
		this.tour = tour;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Tour getTour() {
		return tour;
	}

	public void setTour(Tour tour) {
		this.tour = tour;
	}
	
	
}
