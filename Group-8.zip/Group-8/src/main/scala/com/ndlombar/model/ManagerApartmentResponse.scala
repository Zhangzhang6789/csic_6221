package com.ndlombar.model;

import java.util.List;

import com.ndlombar.entity.Apartment;
import com.ndlombar.entity.ManagerApartments;

public class ManagerApartmentResponse {
	private boolean success;
	private List<ManagerApartments> apartments;
	
	public ManagerApartmentResponse() {}
	
	public ManagerApartmentResponse(boolean success, List<ManagerApartments> apartments) {
		this.success = success;
		this.apartments = apartments;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public List<ManagerApartments> getApartments() {
		return apartments;
	}

	public void setApartments(List<ManagerApartments> apartments) {
		this.apartments = apartments;
	}
	
	
}
