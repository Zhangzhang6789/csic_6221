package com.ndlombar.model;

import java.util.List;

import com.ndlombar.entity.Forumgroup;
import com.ndlombar.entity.Forumtopic;
import com.ndlombar.entity.Topicmessage;

public class ForumResponse {
	private boolean success;
	private List<Forumgroup> groups;
	private List<Forumtopic> topics;
	private List<Topicmessage> messages;
	
	public ForumResponse() {}
	
	public ForumResponse(boolean success, List<Forumgroup> groups, List<Forumtopic> topics, List<Topicmessage> messages) {
		this.success = success;
		this.groups = groups;
		this.topics = topics;
		this.messages = messages;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public List<Forumgroup> getGroups() {
		return groups;
	}

	public void setGroups(List<Forumgroup> groups) {
		this.groups = groups;
	}

	public List<Forumtopic> getTopics() {
		return topics;
	}

	public void setTopics(List<Forumtopic> topics) {
		this.topics = topics;
	}

	public List<Topicmessage> getMessages() {
		return messages;
	}

	public void setMessages(List<Topicmessage> messages) {
		this.messages = messages;
	}
	
	
}
