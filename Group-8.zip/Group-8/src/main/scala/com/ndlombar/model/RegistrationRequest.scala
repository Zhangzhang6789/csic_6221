package com.ndlombar.model;


public class RegistrationRequest {
	private char role;
	private String firstname;
	private String lastname;
	private String email;
	private String phone;
	private String password; 
//	private String securityQuestion1;
//	private String answer1;
//	private String securityQuestion2;
//	private String answer2;
//	private String securityQuestion3;
//	private String answer3;
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public char getRole() {
		return role;
	}
	public void setRole(char role) {
		this.role = role;
	}
//	public String getSecurityQuestion1() {
//		return securityQuestion1;
//	}
//	public void setSecurityQuestion1(String securityQuestion1) {
//		this.securityQuestion1 = securityQuestion1;
//	}
//	public String getAnswer1() {
//		return answer1;
//	}
//	public void setAnswer1(String answer1) {
//		this.answer1 = answer1;
//	}
//	public String getSecurityQuestion2() {
//		return securityQuestion2;
//	}
//	public void setSecurityQuestion2(String securityQuestion2) {
//		this.securityQuestion2 = securityQuestion2;
//	}
//	public String getAnswer2() {
//		return answer2;
//	}
//	public void setAnswer2(String answer2) {
//		this.answer2 = answer2;
//	}
//	public String getSecurityQuestion3() {
//		return securityQuestion3;
//	}
//	public void setSecurityQuestion3(String securityQuestion3) {
//		this.securityQuestion3 = securityQuestion3;
//	}
//	public String getAnswer3() {
//		return answer3;
//	}
//	public void setAnswer3(String answer3) {
//		this.answer3 = answer3;
//	}
	
}
