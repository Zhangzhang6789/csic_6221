package com.ndlombar.model;

import java.sql.Date;

import javax.persistence.Column;

public class NewLeaseRequest {
	private Integer userId;
	private Integer requestedProperty;
	private String additionalInformation;
	private String occupants;
	private String leaseType;
	private String startDate;
	private String endDate;
	private String signature;
	private String filingDate;
	
	public NewLeaseRequest() {	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getRequestedProperty() {
		return requestedProperty;
	}

	public void setRequestedProperty(Integer requestedProperty) {
		this.requestedProperty = requestedProperty;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getOccupants() {
		return occupants;
	}

	public void setOccupants(String occupants) {
		this.occupants = occupants;
	}

	public String getLeaseType() {
		return leaseType;
	}

	public void setLeaseType(String leaseType) {
		this.leaseType = leaseType;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getFilingDate() {
		return filingDate;
	}

	public void setFilingDate(String filingDate) {
		this.filingDate = filingDate;
	}
	
	
}
