package com.ndlombar.model;

import com.ndlombar.entity.Posting;

public class PostResponse {
	private boolean success;
	private Posting post;
	
	public PostResponse() {}
	
	public PostResponse(boolean success, Posting post) {
		this.success = success;
		this.post = post;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Posting getPost() {
		return post;
	}

	public void setPost(Posting post) {
		this.post = post;
	}
	
	
	
}
