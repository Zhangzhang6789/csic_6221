package com.ndlombar.model;

import com.ndlombar.entity.ResidentPortal;
import com.ndlombar.entity.User;

public class ResidentPortalResponse {
	private boolean success;
	private ResidentPortal user;
	
	public ResidentPortalResponse(boolean success, ResidentPortal user) {
		 this.success = success;
		 this.user = user;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public ResidentPortal getUser() {
		return user;
	}

	public void setUser(ResidentPortal user) {
		this.user = user;
	}
	 
	
}
