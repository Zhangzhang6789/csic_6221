package com.ndlombar.model;

import java.util.List;

import com.ndlombar.entity.Announcement;

public class MessageResponse {
	private boolean success;
	private List<Announcement> announcements;
	
	public MessageResponse() {}
	
	public MessageResponse(boolean success, List<Announcement> announcements) {
		this.success = success;
		this.announcements = announcements;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public List<Announcement> getAnnouncements() {
		return announcements;
	}

	public void setAnnouncements(List<Announcement> announcements) {
		this.announcements = announcements;
	}
	
}
