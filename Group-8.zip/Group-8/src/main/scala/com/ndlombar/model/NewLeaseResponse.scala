package com.ndlombar.model;

import java.rmi.dgc.Lease;

import com.ndlombar.entity.Leaserequest;

public class NewLeaseResponse {
	private boolean success;
	private Leaserequest lease;
	
	public NewLeaseResponse() {}
	
	public NewLeaseResponse(boolean success, Leaserequest lease) {
		this.success = success;
		this.lease = lease;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Leaserequest getLease() {
		return lease;
	}

	public void setLease(Leaserequest lease) {
		this.lease = lease;
	}
	
	
}
