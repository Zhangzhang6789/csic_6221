package com.ndlombar.model;


import com.ndlombar.entity.User;

public class UserResponse {
	 private boolean success;
	 private Integer aid;
	 private User user;
	 
	 public UserResponse(boolean success, User user, Integer aid) {
		 this.success = success;
		 this.user = user;
		 this.aid = aid;
	 }
	 
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	public Integer getAid() {
		return aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}
	
	
}
