package com.ndlombar.model;

import com.ndlombar.entity.Forumgroup;

public class NewGroupResponse {
	private boolean success;
	private Forumgroup group;
	
	public NewGroupResponse() {}
	
	public NewGroupResponse(boolean success, Forumgroup group) {
		this.success = success;
		this.group = group;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Forumgroup getGroup() {
		return group;
	}

	public void setGroup(Forumgroup group) {
		this.group = group;
	}
	
	
	
}
