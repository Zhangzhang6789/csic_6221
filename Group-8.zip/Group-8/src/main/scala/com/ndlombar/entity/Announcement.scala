package com.ndlombar.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity 
@EntityListeners(AuditingEntityListener.class)
@Table(name="announcement")  
public class Announcement {
	@Id
	@Column(name = "mid")  private Integer messageId;
	@Column(name = "manager_id")  private Integer managerId;
	@Column(name = "title")  private String title;
	@Column(name = "message")  private String message;
	@Column(name = "post_date")  private Date postDate;
	
	public Announcement() {}
	
	public Announcement(Integer mid, Integer managerId, String title, String message, Date postDate) {
		this.messageId = mid;
		this.managerId = managerId;
		this.title = title;
		this.message = message;
		this.postDate = postDate;
	}

	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getPostDate() {
		return postDate;
	}

	public void setPostDate(Date postDate) {
		this.postDate = postDate;
	}

	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
}
