package com.ndlombar.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity 
@EntityListeners(AuditingEntityListener.class)
@Table(name="leaserequest")  
public class Leaserequest {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "lid")  private Integer lid;
	@Column(name = "user_id") private Integer userId;
	@Column(name = "requested_property") private Integer requestedProperty;
	@Column(name = "additional_information")  private String additionalInformation;
	@Column(name = "occupants")  private String occupants;
	@Column(name = "lease_type") private String leaseType;
	@Column(name = "start_date") private String startDate;
	@Column(name = "end_date") private String endDate;
	@Column(name = "signature")private String signature;
	@Column(name = "filing_date")private String filingDate;
	
	public Leaserequest() {}
	
	public Leaserequest(Integer lid, Integer userId, Integer requestedProperty, String additionalInformation,
			String occupants, String leaseType, String startDate, String endDate, String signature, String filingDate) {
		this.lid = lid;
		this.userId = userId;
		this.requestedProperty = requestedProperty;
		this.additionalInformation = additionalInformation;
		this.occupants = occupants;
		this.leaseType = leaseType;
		this.startDate = startDate;
		this.endDate = endDate;
		this.signature = signature;
		this.filingDate = filingDate;
	}

	public Integer getLid() {
		return lid;
	}

	public void setLid(Integer lid) {
		this.lid = lid;
	}

	public Integer getRequestedProperty() {
		return requestedProperty;
	}

	public void setRequestedProperty(Integer requestedProperty) {
		this.requestedProperty = requestedProperty;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getOccupants() {
		return occupants;
	}

	public void setOccupants(String occupants) {
		this.occupants = occupants;
	}

	public String getLeaseType() {
		return leaseType;
	}

	public void setLeaseType(String leaseType) {
		this.leaseType = leaseType;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getFilingDate() {
		return filingDate;
	}

	public void setFilingDate(String filingDate) {
		this.filingDate = filingDate;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
}
