package com.ndlombar.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
 
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="due")
public class Due {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "did", unique=true, nullable=false)private Integer did;
	@Column(name = "chargedate")  private Date chargeDate;
	@Column(name = "duedate")  private Date dueDate;
	@Column(name = "uid")  private Integer uid;
	@Column(name = "aid")  private Integer aid;
	@Column(name = "reason")  private String reason;
	@Column(name = "amount") private Double amount;
	
	public Due(Date chargeDate, Date dueDate, Integer uid, Integer aid, String reason, Double amount) {
		this.chargeDate = chargeDate;
		this.dueDate = dueDate;
		this.reason = reason;
		this.amount = amount;
		this.uid = uid;
		this.aid = aid;
	}
	public Due() {}

	public Integer getDid() {
		return did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public Date getChargeDate() {
		return chargeDate;
	}

	public void setChargeDate(Date chargeDate) {
		this.chargeDate = chargeDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Integer getAid() {
		return aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
	
}
