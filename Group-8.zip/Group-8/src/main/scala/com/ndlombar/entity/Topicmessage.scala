package com.ndlombar.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity 
@EntityListeners(AuditingEntityListener.class)
@Table(name="topicmessage")  
public class Topicmessage {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "mid")  private Integer mid;
	@Column(name = "tid")  private Integer tid;
	@Column(name = "uid")  private Integer uid;
	@Column(name = "user_name") private String userName;
	@Column(name = "time")  private Timestamp time;
	@Column(name = "message")  private String message;
	
	public Topicmessage() {}
	
	public Topicmessage(Integer mid, Integer tid, Integer uid, String userName, Timestamp time, String message) {
		this.mid = mid;
		this.uid = uid;
		this.tid = tid;
		this.userName = userName;
		this.time = time;
		this.message = message;
	}

	public Integer getMid() {
		return mid;
	}

	public void setMid(Integer mid) {
		this.mid = mid;
	}

	public Integer getTid() {
		return tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Timestamp getTime() {
		return time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	
}
