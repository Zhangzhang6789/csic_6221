package com.ndlombar.entity;

import java.util.List;

public class ResidentPortal {
	private User user;
	private List<Statement> statements;
	private List<Ticket> tickets;
	private List<Due> dues;
	private List<Coupon> coupons;
	
	public ResidentPortal() {}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
 
	public List<Statement> getStatements() {
		return statements;
	}

	public void setStatements(List<Statement> statements) {
		this.statements = statements;
	}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	public List<Due> getDues() {
		return dues;
	}

	public void setDues(List<Due> dues) {
		this.dues = dues;
	}

	public List<Coupon> getCoupons() {
		return coupons;
	}

	public void setCoupons(List<Coupon> coupons) {
		this.coupons = coupons;
	}
	
	
	
	
}
