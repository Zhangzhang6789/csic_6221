package com.ndlombar.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="ticket")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "tktid", unique=true, nullable=false)private Integer tktid;
	@Column(name = "date")  private Timestamp date;
	@Column(name = "uid")  private Integer uid;
	@Column(name = "aid")  private Integer aid;
	@Column(name = "title")  private String title;
	@Column(name = "type")  private String type;
	@Column(name = "priority")  private String priority;
	@Column(name = "description")  private String description;
	@Column(name = "status")  private String status;
	 
	public Ticket() {}
	
	public Ticket(Timestamp date, Integer aid, Integer uid,String title, String type, String priority,
			String description, String status) {
		this.date = date;
		this.aid = aid;
		this.uid = uid;
		this.title = title;
		this.type = type;
		this.priority = priority;
		this.description = description;
		this.status = status;
	}

	public Integer getTktid() {
		return tktid;
	}

	public void setTktid(Integer tktid) {
		this.tktid = tktid;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Integer getAid() {
		return aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
}
