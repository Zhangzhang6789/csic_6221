package com.ndlombar.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id; 
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="statement")
public class Statement { 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "stid", unique=true, nullable=false)private Integer stid;
	@Column(name = "date")  private Timestamp date;
	@Column(name = "amount")  private Double amount;
	@Column(name = "uid")  private Integer uid;
	
	public Statement() {}
	
	public Statement(Timestamp date, Double amount, Integer uid) {
		this.date = date;
		this.amount = amount; 
		this.uid = uid;
	}

	public Integer getStid() {
		return stid;
	}

	public void setStid(Integer stid) {
		this.stid = stid;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}
	
	
}
