package com.ndlombar.entity;

import java.awt.image.TileObserver;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity 
@EntityListeners(AuditingEntityListener.class)
@Table(name="forumtopic")  
public class Forumtopic {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "tid")  private Integer tid;
	@Column(name = "gid")  private Integer gid;
	@Column(name = "title")  private String title;
	@Column(name = "description")  private String description;
	@Column(name = "message")  private String message;
	
	public Forumtopic() {}
	
	public Forumtopic(Integer tid, Integer gid, String title, String description, String message) {
		this.tid = tid;
		this.gid = gid;
		this.title = title;
		this.description = description;
		this.message = message;
	}

	public Integer getTid() {
		return tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public Integer getGid() {
		return gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
	
