package com.ndlombar.entity;

import java.util.List;

public class ManagerApartments {
	private Apartment apartment;
	private List<Tour> tours;
	
	public ManagerApartments() {}
	
	public ManagerApartments(Apartment apartment, List<Tour> tours) {
		this.apartment = apartment;
		this.tours = tours;
	}

	public Apartment getApartment() {
		return apartment;
	}

	public void setApartment(Apartment apartment) {
		this.apartment = apartment;
	}

	public List<Tour> getTours() {
		return tours;
	}

	public void setTours(List<Tour> tours) {
		this.tours = tours;
	}
	
	
}
