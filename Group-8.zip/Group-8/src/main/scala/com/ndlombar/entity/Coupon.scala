package com.ndlombar.entity;

public class Coupon {
	private String code;
	private String prefix;
	private Double discount;
	
	public Coupon() {}
	
	public Coupon(String code, String prefix, Double discount) {
		//super();
		this.code = code;
		this.prefix = prefix;
		this.discount = discount;
	}



	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	
	
}
