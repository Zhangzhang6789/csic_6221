package com.ndlombar.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity 
@EntityListeners(AuditingEntityListener.class)
@Table(name="forumgroup")  
public class Forumgroup {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "gid")  private Integer gid;
	@Column(name = "name")  private String name;
	@Column(name = "description")  private String description;
	
	
	public Forumgroup() {}
	
	public Forumgroup(Integer gid, String name, String description) {
		this.gid = gid;
		this.name = name;
		this.description = description;
	}

	public Integer getGid() {
		return gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
