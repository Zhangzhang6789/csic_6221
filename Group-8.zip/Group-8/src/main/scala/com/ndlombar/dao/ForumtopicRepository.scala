package com.ndlombar.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ndlombar.entity.Forumtopic;

@Repository
public interface ForumtopicRepository extends CrudRepository<Forumtopic, Integer>{
	Forumtopic findForumtopicByTid(Integer tid);
}
