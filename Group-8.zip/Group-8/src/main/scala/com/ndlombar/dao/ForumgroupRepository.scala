package com.ndlombar.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ndlombar.entity.Forumgroup;

@Repository
public interface ForumgroupRepository extends CrudRepository<Forumgroup, Integer> {
	
	Forumgroup findForumgroupByGid(Integer gid);

}
