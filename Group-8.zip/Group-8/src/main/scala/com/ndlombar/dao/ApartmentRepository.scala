package com.ndlombar.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ndlombar.entity.Apartment;

@Repository
public interface ApartmentRepository   extends CrudRepository<Apartment, Integer>{
	Apartment findApartmentByPostingId(int postingId); 
	Apartment findApartmentByApartmentId(int aid);
	
	@Transactional 
	@Query("select apartmentId from Apartment where tenantId=?1")
	List<Object> getApartmentIdfromUserId(Integer uid);
	
//	@Transactional
//	@Query("select * from Apartment where managerId=?1")
	List<Apartment> getApartmentsByManagerId(Integer mid);
}
 