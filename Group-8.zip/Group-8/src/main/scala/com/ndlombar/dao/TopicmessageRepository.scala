package com.ndlombar.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ndlombar.entity.Topicmessage;

@Repository
public interface TopicmessageRepository extends CrudRepository<Topicmessage, Integer> {

}
