package com.ndlombar.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ndlombar.entity.Ticket;

public interface TicketRepository  extends CrudRepository<Ticket, Integer>{
	List<Ticket> findAllByUid(int uid);
}
 