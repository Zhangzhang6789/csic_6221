package com.ndlombar.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ndlombar.entity.Leaserequest;

@Repository
public interface LeaserequestRepository extends CrudRepository<Leaserequest, Integer>{

}
