package com.ndlombar.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ndlombar.entity.Image;

@Repository
public interface ImageRepository  extends CrudRepository<Image, Integer>{
	List<Image> findAllByAid(int aid);
	Image findFirstByAid(int aid);
}
